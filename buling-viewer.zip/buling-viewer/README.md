# 卜灵 モーションビューア

構成(ビューアとキャラを分離)
- `index.html` / `js/app.js` … 床のマス目・カメラ・モーション(通常攻撃1段目)・服/髪の物理・貫通チェック
- `assets/buling.glb` … キャラ(軽量化済み)。**ビューアとは独立**
- `serve.py` … CORS付きの簡易サーバー(GLB専用サーバーとしても使える)

## GitHub Pagesで公開
1. リポジトリを作成して全ファイルをpush
2. Settings → Pages → Branch: `main` / `(root)` → Save
3. `https://<ユーザー名>.github.io/<リポジトリ名>/` を開く

## キャラを別サーバーに置く
GLBを別ホストに置き、ビューアのURLに指定します。
`https://<ユーザー名>.github.io/<repo>/?model=https://your-server.example/buling.glb`
別サーバー側で `Access-Control-Allow-Origin` を許可してください(`serve.py` は許可済み)。
この場合 `assets/buling.glb` はリポジトリに含めなくて構いません。

## 注意
GLBのメタ情報に「Personal use only; do not redistribute」とあります。
公開リポジトリやGitHub PagesにGLBを置くと再配布になるため、**GLBはprivateなサーバーに置き、
ビューア(コードのみ)だけを公開する**構成を推奨します。`.gitignore` でGLBを除外済みです。
