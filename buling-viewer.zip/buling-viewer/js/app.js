const T=THREE,$=s=>document.querySelector(s),D=Math.PI/180,V=()=>new T.Vector3(),Q=()=>new T.Quaternion();
const X=new T.Vector3(1,0,0),Z=new T.Vector3(0,0,1),hud=$('#hud');
const renderer=new T.WebGLRenderer({antialias:true});renderer.setPixelRatio(Math.min(devicePixelRatio,2));
renderer.outputEncoding=T.sRGBEncoding;renderer.shadowMap.enabled=true;renderer.shadowMap.type=T.PCFSoftShadowMap;
document.body.appendChild(renderer.domElement);
const scene=new T.Scene(),cam=new T.PerspectiveCamera(32,1,.05,60);
const setBg=()=>{scene.background=new T.Color(getComputedStyle(document.documentElement).getPropertyValue('--bg').trim()||'#eef2f5')};
setBg();matchMedia('(prefers-color-scheme: dark)').addEventListener('change',()=>setTimeout(setBg,0));
const ctl=new T.OrbitControls(cam,renderer.domElement);ctl.target.set(0,.85,0);ctl.enableDamping=true;ctl.maxPolarAngle=Math.PI*.495;
function view(a){const r=3.6;cam.position.set(Math.sin(a*D)*r,1.15,Math.cos(a*D)*r);ctl.update()}view(0);
function resize(){renderer.setSize(innerWidth,innerHeight);cam.aspect=innerWidth/innerHeight;cam.updateProjectionMatrix()}addEventListener('resize',resize);resize();
// ---- 床(1マス=0.5m、太線=1m) ----
const grid=new T.GridHelper(12,24,0x0a9ac4,0x7f919c);grid.position.y=.001;scene.add(grid);
const g1=new T.GridHelper(12,12,0x0a9ac4,0x0a9ac4);g1.position.y=.002;g1.material.opacity=.55;g1.material.transparent=true;scene.add(g1);
const sh=new T.Mesh(new T.PlaneGeometry(12,12).rotateX(-Math.PI/2),new T.ShadowMaterial({opacity:.28}));sh.receiveShadow=true;scene.add(sh);
scene.add(new T.HemisphereLight(0xffffff,0x6a7a88,.95));
const dl=new T.DirectionalLight(0xffffff,1.1);dl.position.set(2,4,3);dl.castShadow=true;dl.shadow.mapSize.set(2048,2048);
Object.assign(dl.shadow.camera,{left:-2,right:2,top:2,bottom:-2,near:.5,far:10});dl.shadow.bias=-.0004;scene.add(dl);
// モデルは別ファイル/別サーバー。?model=https://example.com/x.glb で差し替え可能(CORS許可が必要)
const MODEL=new URLSearchParams(location.search).get('model')||'./assets/buling.glb';
new T.GLTFLoader().load(MODEL,init,p=>{hud.textContent='読み込み中 '+(p.total?Math.round(p.loaded/p.total*100)+'%':'')},
 e=>{hud.textContent='GLB読込エラー: '+MODEL+'\nパスとCORS設定を確認してください'});

function init(gltf){
const model=gltf.scene;scene.add(model);const B={};
model.traverse(o=>{if(o.isBone)B[o.name]=o;if(o.isMesh){o.castShadow=true;o.frustumCulled=false;[].concat(o.material).forEach(m=>{if('metalness'in m){m.metalness=0;m.roughness=.9}})}});
model.updateMatrixWorld(true);
const rest=new Map();Object.values(B).forEach(b=>rest.set(b,b.quaternion.clone()));
const wp=n=>B[n].getWorldPosition(V()),ctr=B['センター'],ctr0=ctr.position.clone();
// ---- 腕の基準方向 ----
const arm={};for(const[s,sg]of[['右',-1],['左',1]]){const a=wp(s+'腕'),e=wp(s+'ひじ'),w=wp(s+'手首');
 const d0=e.clone().sub(a).normalize();arm[s]={sg,d0,d1:w.clone().sub(e).normalize(),r0:Math.acos(-d0.y)/D}}
function armPose(s,ev,fw,tw,fl){const a=arm[s];const q1=Q().setFromAxisAngle(Z,a.sg*(ev-a.r0)*D),tg=a.d0.clone().applyQuaternion(q1);
 const n=V().crossVectors(tg,Z).normalize();
 B[s+'腕'].quaternion.copy(Q().setFromAxisAngle(tg,tw*D).multiply(Q().setFromAxisAngle(n,fw*D)).multiply(q1));
 B[s+'ひじ'].quaternion.setFromAxisAngle(V().crossVectors(a.d1,Z).normalize(),fl*D)}
function legPose(s,f,ab,k,fl,af){const sg=s==='右'?-1:1;
 B[s+'足'].quaternion.copy(Q().setFromAxisAngle(Z,sg*ab*D).multiply(Q().setFromAxisAngle(X,-f*D)));
 B[s+'ひざ'].quaternion.setFromAxisAngle(X,Math.max(0,k)*D);
 B[s+'足首'].quaternion.setFromAxisAngle(X,((f-k)*fl+af)*D)}
const eul=(n,x,y,z,w)=>B[n].quaternion.setFromEuler(new T.Euler(x*w*D,y*w*D,z*w*D,'YXZ'));
// ---- 動画(通常攻撃1段目)から読み取ったキーポーズ ----
const R=arm['右'].r0,L=arm['左'].r0;
const Z0={cy:0,cz:0,yaw:0,ubp:0,uby:0,ubr:0,hdp:0,hdy:0,hdr:0,rev:R,rfw:0,rtw:0,re:0,lev:L,lfw:0,ltw:0,le:0,
 rlf:0,rla:0,rk:0,rfl:1,rf:0,llf:0,lla:0,lk:0,lfl:1,lf:0,g:1};
const KEY=[[0,{}],
[.10,{yaw:-25,cz:.05,ubp:14,uby:30,hdp:-8,hdy:-30,rev:105,rfw:40,re:50,lev:50,lfw:-30,le:70,rlf:30,rk:75,rfl:0,rf:20,llf:20,lk:55}],
[.20,{yaw:180,cy:.14,g:0,ubp:10,hdp:6,rev:120,rfw:30,re:20,lev:100,lfw:10,le:20,rlf:45,rk:90,rfl:0,rf:25,llf:35,lk:90,lfl:0,lf:25}],
[.30,{yaw:330,cy:.06,g:0,ubp:8,rev:105,rfw:10,re:15,lev:100,lfw:10,le:15,rlf:40,rk:100,rfl:0,rf:25,llf:20,lk:50,lfl:.6}],
[.40,{yaw:360,ubp:-3,ubr:-4,hdr:8,rev:100,rfw:-5,re:10,lev:98,lfw:-5,le:10,rlf:38,rk:100,rfl:0,rf:25,llf:4,lk:14}],
[1.5,{yaw:360,ubp:-3,ubr:-4,hdr:8,rev:104,rfw:-8,re:12,lev:96,lfw:-8,le:12,rlf:34,rk:104,rfl:0,rf:25,llf:4,lk:14}],
[1.9,{yaw:360,ubr:-8,hdr:0,rev:160,rfw:0,re:22,lev:80,lfw:18,le:35,rlf:12,rk:30,rfl:.6,llf:3,lk:8}],
[2.3,{yaw:360,ubr:-6,rev:172,rfw:0,re:15,lev:62,lfw:25,le:48}],
[2.8,{yaw:360,ubp:6,uby:-15,rev:110,rfw:40,re:70,lev:50,lfw:30,le:70}],
[3.3,{yaw:360,uby:-8,rev:52,rfw:30,re:80,lev:46,lfw:28,le:80,rlf:8,llf:6}],
[3.8,{yaw:360,uby:-8,rev:52,rfw:30,re:80,lev:46,lfw:28,le:80,rlf:8,llf:6}],
[4.4,{yaw:360}]].map(([t,o])=>({t,...Z0,...o}));
const DUR=4.4,ks=Object.keys(Z0),sm=x=>x*x*x*(x*(x*6-15)+10);
function sample(t){let i=0;while(i<KEY.length-2&&t>KEY[i+1].t)i++;const a=KEY[i],b=KEY[i+1],s=sm(Math.min(1,Math.max(0,(t-a.t)/(b.t-a.t))));
 const o={};ks.forEach(k=>o[k]=a[k]+(b[k]-a[k])*s);return o}
const feet=['右足首','左足首','右つま先','左つま先'].map(n=>({b:B[n],y0:wp(n).y}));let floorMin=0;
function applyPose(t){const p=sample(t);
 ctr.position.set(ctr0.x,ctr0.y+p.cy,ctr0.z+p.cz);ctr.quaternion.setFromAxisAngle(new T.Vector3(0,1,0),p.yaw*D);
 eul('上半身',p.ubp,p.uby,p.ubr,.4);eul('上半身1',p.ubp,p.uby,p.ubr,.3);eul('上半身2',p.ubp,p.uby,p.ubr,.3);
 eul('首',p.hdp,p.hdy,p.hdr,.4);eul('頭',p.hdp,p.hdy,p.hdr,.6);
 armPose('右',p.rev,p.rfw,p.rtw,p.re);armPose('左',p.lev,p.lfw,p.ltw,p.le);
 legPose('右',p.rlf,p.rla,p.rk,p.rfl,p.rf);legPose('左',p.llf,p.lla,p.lk,p.lfl,p.lf);
 model.updateMatrixWorld(true);
 let m=1e9;const v=V();feet.forEach(f=>{m=Math.min(m,f.b.getWorldPosition(v).y-f.y0)});
 if(m<0||p.g>.5){ctr.position.y-=m;model.updateMatrixWorld(true);m=0}floorMin=m}
// ---- 衝突体(体の各部をカプセルで近似) ----
const CD=[['右足','右ひざ',.1,.075],['左足','左ひざ',.1,.075],['右ひざ','右足首',.072,.05],['左ひざ','左足首',.072,.05],['右足','左足',.1,.1],
['下半身','首',.125,.115],['右腕','左腕',.07,.07],['右腕','右ひじ',.05,.042],['左腕','左ひじ',.05,.042],
['右ひじ','右手首',.042,.036],['左ひじ','左手首',.042,.036],['右手首','右手先',.05,.05],['左手首','左手先',.05,.05],['頭','頭先',.115,.11]];
const cols=CD.map(([a,b,ra,rb])=>({A:B[a],B:B[b],ra,rb,a:V(),b:V()}));
const refreshCols=()=>cols.forEach(c=>{c.A.getWorldPosition(c.a);c.B.getWorldPosition(c.b)});
const dbg=new T.Group();dbg.visible=false;scene.add(dbg);
const wm=new T.MeshBasicMaterial({color:0xff3b6b,wireframe:true,transparent:true,opacity:.5,depthTest:false});
cols.forEach(c=>{c.sa=new T.Mesh(new T.SphereGeometry(1,12,8),wm);c.sb=new T.Mesh(new T.SphereGeometry(1,12,8),wm);dbg.add(c.sa,c.sb)});
// ---- 服・髪・飾りのスプリング物理(慣性＋復元力＋長さ拘束＋衝突押し出し) ----
const GR=/^(Dress_|M_Coat_|Liusu_|HairTail_|HairBow_|Piao|Bianzi_|[右左]?(Belt_|SHair_|BHair_|Earphone_)|M_Bow_|Headbow_|FHair_|SHair_)/,inG=o=>o&&o.isBone&&GR.test(o.name);
const sims=[];model.traverse(o=>{if(!inG(o))return;const k=o.children.filter(inG);if(!k.length)return;const c=k[0];
 const hair=/Hair|Bianzi|Bow|Earphone/.test(o.name),cloth=/^(Dress|M_Coat)/.test(o.name);
 sims.push({b:o,dir:c.position.clone().normalize(),L:c.getWorldPosition(V()).distanceTo(o.getWorldPosition(V())),cur:V(),prev:V(),init:false,
 st:hair?.12:cloth?.2:.1,dr:hair?.08:.14,pr:cloth?.035:.02,gv:hair?6:3})});
const tv=V(),hd=V(),tg=V(),nx=V(),rd=V(),ab=V(),qq=Q(),bq=Q(),pq=Q();let minC=0,nPen=0;
function pushOut(p,pr){let w=1e9;for(const c of cols){ab.subVectors(c.b,c.a);const s=Math.min(1,Math.max(0,tv.subVectors(p,c.a).dot(ab)/(ab.lengthSq()||1)));
 tv.copy(ab).multiplyScalar(s).add(c.a);const r=c.ra+(c.rb-c.ra)*s+pr;ab.subVectors(p,tv);const l=ab.length();
 if(l<r){p.copy(tv).addScaledVector(l>1e-6?ab.divideScalar(l):nx.set(0,1,0),r);} w=Math.min(w,l-r)}return w}
function simulate(dt,reset){minC=1e9;nPen=0;const f=Math.min(1,dt*60);
 for(const e of sims){const b=e.b;b.quaternion.copy(rest.get(b));b.updateMatrixWorld(true);
  b.getWorldPosition(hd);b.getWorldQuaternion(bq);rd.copy(e.dir).applyQuaternion(bq);tg.copy(hd).addScaledVector(rd,e.L);
  if(reset||!e.init){e.cur.copy(tg);e.prev.copy(tg);e.init=true}
  nx.copy(e.cur).addScaledVector(tv.subVectors(e.cur,e.prev),Math.pow(1-e.dr,dt*60));
  nx.y-=e.gv*dt*dt;nx.addScaledVector(tv.subVectors(tg,e.cur),e.st*f);
  for(let i=0;i<3;i++){nx.sub(hd).setLength(e.L).add(hd);pushOut(nx,e.pr)}
  nx.sub(hd).setLength(e.L).add(hd);const w=pushOut(nx,e.pr);minC=Math.min(minC,w);if(w<-.0005)nPen++;
  e.prev.copy(e.cur);e.cur.copy(nx);
  qq.setFromUnitVectors(rd,tv.subVectors(nx,hd).normalize());qq.multiply(bq);b.parent.getWorldQuaternion(pq);
  b.quaternion.copy(pq.invert().multiply(qq));b.updateMatrixWorld(true)}}
const restoreAll=()=>{sims.forEach(e=>e.b.quaternion.copy(rest.get(e.b)));model.updateMatrixWorld(true)};
// ---- 再生制御 ----
let t=0,play=true,speed=1,last=performance.now(),reset=true,hudT=0;
$('#ui').hidden=false;const tl=$('#tl');
$('#pl').onclick=()=>{play=!play;$('#pl').textContent=play?'❚❚ 停止':'▶ 再生'};
tl.oninput=()=>{t=tl.value*DUR;reset=true};$('#sp').onchange=e=>speed=+e.target.value;
$('#cd').onchange=e=>dbg.visible=e.target.checked;
$('#ph').onchange=e=>{if(e.target.checked)reset=true;else restoreAll()};
document.querySelectorAll('[data-v]').forEach(b=>b.onclick=()=>view(+b.dataset.v));
function frame(now){requestAnimationFrame(frame);const dt=Math.min((now-last)/1000,.05);last=now;
 if(play){t+=dt*speed;if(t>=DUR)t-=DUR}
 applyPose(t);
 if($('#ph').checked){refreshCols();
  if(reset){for(let i=0;i<40;i++)simulate(1/60,i===0);reset=false}
  else if(play){simulate(dt*speed/2);simulate(dt*speed/2)}else simulate(1/600)}
 if(dbg.visible){refreshCols();cols.forEach(c=>{c.sa.position.copy(c.a);c.sa.scale.setScalar(c.ra);c.sb.position.copy(c.b);c.sb.scale.setScalar(c.rb)})}
 tl.value=t/DUR;$('#tt').textContent=t.toFixed(2)+'s';
 if(now-hudT>200){hudT=now;hud.textContent='通常攻撃1段目 ／ 揺れ物ボーン '+sims.length+'本 ／ 衝突体 '+cols.length+'個\n'+
  '衣服・髪の貫通点: '+($('#ph').checked?nPen:'-')+'　最小余裕: '+($('#ph').checked?(minC*1000).toFixed(1)+'mm':'-')+'　足と床の最小距離: '+(floorMin*1000).toFixed(1)+'mm'}
 ctl.update();renderer.render(scene,cam)}
requestAnimationFrame(frame)}
