#!/usr/bin/env python3
"""ローカル/別サーバー用の簡易サーバー。CORSを許可するので、GLBだけを別ホストに置けます。
使い方: python3 serve.py [ポート]   → http://localhost:8000/ を開く"""
import sys
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
class H(SimpleHTTPRequestHandler):
    def end_headers(self):
        self.send_header('Access-Control-Allow-Origin','*'); self.send_header('Cache-Control','no-cache')
        super().end_headers()
    extensions_map={**SimpleHTTPRequestHandler.extensions_map,'.glb':'model/gltf-binary','.js':'text/javascript'}
ThreadingHTTPServer(('',int(sys.argv[1]) if len(sys.argv)>1 else 8000),H).serve_forever()
